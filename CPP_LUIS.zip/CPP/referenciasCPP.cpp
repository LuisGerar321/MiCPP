#include <iostream>

int all = 42;
int &rall = all;


int main(int argc, char** argv){
	rall  = 30;
	std::cout<<"all: "<<all<<std::endl;
	return EXIT_SUCCESS;
}
