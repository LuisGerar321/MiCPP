#include <iostream>
#include <sstream>
#include <stack>


std::stack<double> mStack;

double reversePolishNotation(std::stringstream &ss, std::stack<double> &mStack);
void getResult(std::string str, std::stack<double>& mStack);
bool isOperator(std::string str);
void argvToString(std::string &str, int argc, char* argv[]);

int main(int argc, char** argv){
	/*Dado argv meterlo en un string! */
	std::string str;
	argvToString(str, argc, argv);
	std::cout<<str<<std::endl;
	/*Creating a stringstream object*/
	std::stringstream ss(str); /*Split in workds*/
	try{
		std::cout<<"Result: "<<reversePolishNotation(ss,mStack)<<std::endl;
	}catch(const char* e){
		std::cout<<e<<std::endl;
	}
	return EXIT_SUCCESS;
}


double reversePolishNotation(std::stringstream &ss, std::stack<double> &mStack){
	std::string str;
	while(ss>>str){
		int num=0;
		std::istringstream iss(str);
		if(iss>>num){
			mStack.push(num);
		}else if(isOperator(str)){
			getResult(str,mStack);
		}else{
			throw "Invalid parameters Sucker!";
		};
	}
	return mStack.top();
}
void getResult(std::string str, std::stack<double> &mStack){

	if(str=="+"){
		double val1, val2;
		val1= mStack.top(); mStack.pop();
		val2 = mStack.top(); mStack.pop();
		mStack.push(val1+val2);
	}
	if(str=="-"){
		double val1, val2;
		val1= mStack.top(); mStack.pop();
		val2 = mStack.top(); mStack.pop();
		mStack.push(val1-val2);
	}
	if(str=="x"){
		double val1, val2;
		val1= mStack.top(); mStack.pop();
		val2 = mStack.top(); mStack.pop();
		mStack.push(val1*val2);
	}
	if(str=="/"){
		double val1, val2;
		val1= mStack.top(); mStack.pop();
		val2 = mStack.top(); mStack.pop();
		mStack.push(val2/val1);
	}
}

bool isOperator(std::string str){
	std::string op[] = {"+","-","x","/"};
	for(int i=0; i<4; i++){
		if(str==op[i]){
			return true;
		}
	}
	return false;
}


void argvToString(std::string &str, int argc, char* argv[]){
	for(int i=1; i<argc; i++){
		str+=argv[i];
		str+=" ";
	}
}
