#include <stdio.h>
#include <time.h>

void sleep(int segundos){
	int firstStep = time(NULL);
	while(time(NULL)<firstStep+segundos){
		//pass;
	}
}
