#include <stdio.h>
#include "include/utils.h"
/*Variables comunes*/
int myInt = 5;
float myFloat = 1.2;
/*Proto*/

//void GetMoneyPerMonth(struct Hoteles *x);
/*Crear una base de datos de un hotel, donde nos ...*/
struct Hoteles{
	int cuartos;
	int banos;
	char nombre[100]; /*constante string*/
	int dinero;
} Paladium, America = {100, 200,"America", 100000};
/*Creando una estructura de tipo  Hoteles que se llama luisHotel*/
struct Hoteles luisHotel = {4, 8, "luis's hotel", 10};
/*Creando mi segundo hotel*/
struct Hoteles aaronHotel = {16,30,"Aaron's hotel", 10000};
void GetMoneyPerMonth(struct Hoteles *x);

int main(int argc, char **argv){
	/*Imprimir datos*/
	printf("Nombre %s, Cuartos %d, Baños %d\n", luisHotel.nombre, luisHotel.cuartos, luisHotel.banos);
	printf("Nombre  %s, Cuartos %d, Baños %d\n", aaronHotel.nombre, aaronHotel.cuartos, aaronHotel.banos);
	/*Se modifica mi hotel*/
	luisHotel.cuartos+=5;
	luisHotel.banos += 4;
	printf("\n...Despues de modificar el hotel...\n");
	sleep(1);
	printf("Nombre %s, Cuartos %d, Baños %d\n", luisHotel.nombre, luisHotel.cuartos, luisHotel.banos);
	for(int i=1; i<13; i++){
		printf("\nMoth: %i ",i);
		GetMoneyPerMonth(&luisHotel);
		GetMoneyPerMonth(&aaronHotel);
		sleep(1);
	}
	return 0;
}
/*funcion*/
void GetMoneyPerMonth(struct Hoteles *x){
	/*Leer*/
	static int cuartos = 0;
	static int DineroMonth = 0;
	/*Doing math*/
	cuartos = x->cuartos;
	DineroMonth = 100*cuartos;
	/*Store*/
	x->dinero += DineroMonth;
	printf("\nDinero:%d", x->dinero);
}
