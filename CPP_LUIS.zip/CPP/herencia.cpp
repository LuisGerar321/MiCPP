#include <iostream>
#include <vector>
#include <algorithm>

class Persona{
	private:
		std::string name;
		int edad;
	public:
		Persona(std::string, int);
	public:
		void Saludar(Persona);
		std::string get_name();
		void set_name(std::string);
};
Persona::Persona(std::string _name="Luis",int _edad=23){
	name=_name;
	edad = _edad;
};

std::string Persona::get_name(){
	return name;
}
void Persona::set_name(std::string _name){
	name = _name;
}

void Persona::Saludar(Persona otraPersona){
	std::cout<<"Hola "<<otraPersona.get_name()<<"mi nombre es "<<get_name()<<std::endl;
}

class Alumno : public Persona{
	private:
		int nota;
		std::string escuela;
	public:
		Alumno(std::string, int, int, std::string);
	public:
		int get_nota();
		void set_nota(int);
		std::string get_escuela();
		void set_escuela(std::string);
};
Alumno::Alumno(std::string _name, int _edad, int _nota, std::string _escuela) : Persona(_name, _edad){
	nota=_nota;
	escuela = _escuela;
}

int Alumno::get_nota(){
	return nota;
}
void Alumno::set_nota(int _nota){
	nota=_nota;
}
std::string Alumno::get_escuela(){
	return escuela;
}
void Alumno::set_escuela(std::string _escuela){
	escuela = _escuela;
}

int main(int argc, char **argv){
	Persona Luis("LuisGerardo",23);
	Alumno Osiris("Osiris",22,10,"UPY");
	Osiris.Saludar(Luis);
	Luis.Saludar(Osiris);
	std::cout<<Osiris.get_nota()<<std::endl<<Osiris.get_escuela()<<std::endl;
	return EXIT_SUCCESS;
}
