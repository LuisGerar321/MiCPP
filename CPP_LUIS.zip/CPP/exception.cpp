#include <iostream>
#include <math.h>

float Dividir(float param1, float param2){
	return param1/param2;
}

int main(int argc, char **argv){
	std::cout<<Dividir(10,0)<<std::endl;
	return EXIT_SUCCESS;
}
