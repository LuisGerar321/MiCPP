#include <iostream>
#include <stack>

int main(int argc, char** argv){
	std::stack<int> mStack;

	mStack.push(5);
	mStack.push(3);
	mStack.push(1);

	while(!mStack.empty()){
		std::cout<<"The size of mStack : "<<mStack.size()<<std::endl;
		std::cout<<"Element popping "<<mStack.top()<<std::endl;
		mStack.pop();
	}

	return EXIT_SUCCESS;
}
