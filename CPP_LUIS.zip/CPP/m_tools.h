#include <vector>

std::vector<int> sortVector(std::vector<int> v){
	std::cout<<"Sorted Vector"<<std::endl;
	std::vector<int> vector = v;

	for(auto x:vector){
		for(int i = 0 ; i<vector.size()-1; i++){
			if(vector[i]>vector[i+1]){
				int tempo = vector[i+1];
				vector[i+1]=vector[i];
				vector[i] = tempo;
			};
		};
	};

	return vector;
}
void rotateVector(std::vector<char> &v, int steps,std::string direction="right"){
	if(direction=="right"){
		std::cout<<"right"<<std::endl;
		for(int i=0; i<=steps; i++){
			std::cout<<i<<std::endl;
			v.push_back(v[0]);
			v.erase(v.begin()+0);
		};
	}else if(direction=="left"){
		std::cout<<"left"<<std::endl;
		for(int i=0; i<=steps; i++){
			int key = (v.size()-1) - (steps-i);
			v.insert(v.begin(),v[key]);
			v.erase(v.begin()+key);
		}
	};
	std::cout<<"\nRotated!"<<std::endl;
	//for(auto x:v){
		//std::cout<<x<<std::endl;
	//};
}
void rotateString(std::string &v, int steps, std::string direction="right"){
	if(direction == "left"){
		//someCode
		for(int i=0; i<steps; i++){
			v.push_back(v[0]);
			v.erase(v.begin()+0);
		}
	}else if(direction== "right"){
		//someCode
		for(int i=0; i<steps; i++){
			int k=v.length()-1;
			while(k!=0){
				char aux =v[k-1];
				v[k-1]=v[k];
				v[k]=aux;
				k--;
			};
		}
	};
}
