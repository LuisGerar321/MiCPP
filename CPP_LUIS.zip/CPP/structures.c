#include <stdio.h>
#include <time.h>
/*Variables comunes*/
int myInt = 5;
float myFloat = 1.2;

/*ProtoFunciones*/
void sleep(int segundos);

/*Crear una base de datos de un hotel, donde nos ...*/
struct Hoteles{
	int cuartos;
	int banos;
	char *nombre; /*constante string*/
	double dinero;
} Paladium, America = {100, 200,"America", 100000};
/*Creando una estructura de tipo  Hoteles que se llama luisHotel*/
struct Hoteles luisHotel = {4, 8, "luis's hotel", 5500};
/*Creando mi segundo hotel*/
struct Hoteles aaronHotel = {16,30,"Aaron's hotel", 10000};

int main(int argc, char **argv){
	/*Imprimir datos*/
	printf("Nombre %s, Cuartos %d, Baños %d\n", luisHotel.nombre, luisHotel.cuartos, luisHotel.banos);
	printf("Nombre  %s, Cuartos %d, Baños %d\n", aaronHotel.nombre, aaronHotel.cuartos, aaronHotel.banos);
	/*Se modifica mi hotel*/
	luisHotel.cuartos+=5;
	luisHotel.banos += 4;
	printf("\n...Despues de modificar el hotel...\n");
	sleep(5);
	printf("Nombre %s, Cuartos %d, Baños %d\n", luisHotel.nombre, luisHotel.cuartos, luisHotel.banos);
	return 0;
}
void sleep(int segundos){
	int firstStep = time(NULL);
	while(time(NULL)<firstStep+segundos){
		//pass;
	}
}
