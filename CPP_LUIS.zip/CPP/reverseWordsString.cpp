#include <iostream>
#include <algorithm>
#include <vector>
#include <cstring>

std::string str = "The sky is blue";

std::string reverseWords(std::string str);
std::vector<std::string> split(std::string str_, std::string sep_);

int main(int argc, char** argv){
	//std::cout<<reverseWords(str)<<std::endl;
	//char cad[255]="hola,mundo,luis";
	//char sep[2]  =",";
	std::vector<std::string> list  = split("Camara,salinas,luis",",");
	for(auto x:list){
		std::cout<<x<<std::endl;
	}
	std::cout<<"ReverseWords"<<std::endl;
	std::cout<<reverseWords(str)<<std::endl;
	return EXIT_SUCCESS;
}

std::string reverseWords(std::string str){
	std::vector<std::string> list = split(str," ");
	std::string r_string;
	std::reverse(list.rbegin(), list.rend());
	for(auto x:list){
		r_string+=x+" ";
	};
	return r_string;
}

std::vector<std::string> split(std::string str_, std::string sep_){
	std::vector<std::string> returnedVector;
	char str[255];
	char sep[2];
	strcpy(str,str_.c_str());
	strcpy(sep, sep_.c_str());
	char* token = strtok(str, sep);
	while(token){
		returnedVector.push_back(token);
		token  = strtok(NULL, sep);
	}
	return returnedVector;
}
