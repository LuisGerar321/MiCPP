#include <iostream>
#include <vector>

class Persona{
	private:
		std::string name;
		int edad;
		std::string universidad;
	public:
		Persona(std::string name_, int edad_, std::string universidad_){
			name =  name_;
			edad = edad_;
			universidad = universidad_;
		}
	public:
		void Saluda(Persona x){
			std::cout<<"Hola "<<x.name<<"me llamo "<<name<<std::endl;
		}
};


int main(int argc, char **argv){
	Persona luis("Luis Camara", 23, "UPY");
	Persona karla("Karla Odit", 23, "UADY");
	luis.Saluda(karla);
	return EXIT_SUCCESS;
}
