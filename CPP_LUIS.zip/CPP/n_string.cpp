#include <iostream>
#include <sstream>
#include <vector>




int main(int argc, char** argv){
	std::string str =argv[1];
	std::istringstream ss(str);
	double num=0;

	if(ss>>num){
		std::cout<<num<<std::endl;
	}else{
		std::cout<<"You're a sucker!";
	}

	return EXIT_SUCCESS;
}
