#include <iostream>
#include <map>

std::map<int, double> data;

int fibo_recur(int n){
	if(n==1){
		return 1;
	}else if(n==0){
		return 1;
		//return fibo_recur(n-1) + fibo_recur(n-2);
	};
	return fibo_recur(n-1) + fibo_recur(n-2);
}

double fibo_dinamic(int n){
	if(n==0){
		return 1;
	}else if(n==1){
		return 1;
	};
	auto Key = data.find(n); /*Encuentra si en el contener existe la llave n*/
	if(Key != data.end()){ /*Si existe retorna el valor guardado*/
		//std::cout<<"Dic found: "<<data[n]<<std::endl;
		return Key->second;
	}else{ /*Si no existe entonces actualiza la lista y retorna*/
		return data[n]=fibo_dinamic(n-1) + fibo_dinamic(n-2);
		//std::cout<<"Diccionario: "<<data[n]<<std::endl;
		//return data[n];
	};
};

int n=0;

int main(int argc, char **argv){
	data[0]=0;
	std::cout<<"Fibonacci program"<<std::endl;
	std::cout<<"Enter a value to fibonacci"<<std::endl;
	std::cin>>n;
	//std::cout<<fibo_recur(n)<<std::endl;
	std::cout<<fibo_dinamic(n)<<std::endl;
	return EXIT_SUCCESS;
}
