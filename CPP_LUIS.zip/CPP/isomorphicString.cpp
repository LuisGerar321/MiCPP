#include <iostream>
#include <map>
#include <set>


int main(int argc,char** argv){
	std::cout<<"isomorphicString"<<std::endl;
	std::string str1(argv[1]); std::string str2(argv[2]);
	std::cout<<isomorphicString(str1, str2);
	return EXIT_SUCCESS;
}

bool isomorphicString(std::string str1, std::string str2){
	std::map<char, char> mapStr;
	std::set<char> marked;

	if(str1.length()!=str2.length()){
		return false;
	}
	for(int i=0; i<str1.length(); i++){
		//someCode;
		//*Si esta mapeado*//
		if(mapStr[str1[i]]!=mapStr.end()){
			//someCode
			if(mapStr[str1[i]]!=str2[i]){
				return false;
			};
		}else{
			//someCode
			if
			//Si todo va bien!
			mapStr1[str1[i]]=str2[i];
			marked.insert(str2[i]);
		}
	}
	return true;
}
