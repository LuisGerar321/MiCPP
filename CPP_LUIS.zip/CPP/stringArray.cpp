#include <iostream>

std::string str[] = {"Luis", "Rafael", "Angelo", "Jesus"};

int main(int argc, char** argv){

	for(auto x:str){
		std::cout<<x<<std::endl;
	}

	return EXIT_SUCCESS;
}
