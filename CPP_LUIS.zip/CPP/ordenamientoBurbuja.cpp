#include <iostream>
#include <vector>
#include <time.h>


std::vector<int> ordenamientoBurbuja(std::vector<int> v);


int tam=0;

std::vector<int> v;
int main(int argc, char **argv){
	srand(time(NULL));
	std::cout<<"Enter tam of list"<<std::endl;
	std::cin>>tam;
	std::cout<<"Vector desordenado: "<<std::endl;
	for(int  i=0; i<tam; i++){
		v.push_back(rand()%101);
		std::cout<<v[i]<<" ";
	}
	std::vector<int> vOrdenado = ordenamientoBurbuja(v);
	std::cout<<"\nVector Ordenado: "<<std::endl;
	for(auto v : vOrdenado){
		std::cout<<v<<" ";
	}
	return EXIT_SUCCESS;
}
std::vector<int> ordenamientoBurbuja(std::vector<int> v){
	for(int i=0; i<v.size()-1; i++){
		for(int j=0; j<v.size()-i-1; j++){
			if(v[j]>v[j+1]){
				auto temp = v[j];
				v[j]=v[j+1];
				v[j+1]= temp;
			};
		}
	}
	return v;
}
