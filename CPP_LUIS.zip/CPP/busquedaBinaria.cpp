#include <iostream>
#include <vector>
#include <algorithm>
#include <time.h>

bool busquedaBinaria(std::vector<int> v, int start, int end, int desired);

int tam=0;
int desired=0;
bool encontrado = false;
std::vector<int> v;
int main(int argc, char **argv){
	srand(time(NULL));
	std::cout<<"Enter tam of list"<<std::endl;
	std::cin>>tam;
	for(int  i=0; i<tam; i++){
		v.push_back(rand()%101);
		std::cout<<v[i]<<" ";
	}
	std::cout<<"\nEnter number to find: "; std::cin>>desired;
	encontrado = busquedaBinaria(v,0, v.size()-1, desired);
	std::cout<<encontrado<<std::endl;
	return EXIT_SUCCESS;
}

bool busquedaBinaria(std::vector<int> v, int start, int end, int desired){
	if(start>end){
		return false;
	};
	int mid = (start+end)/2;
	//std::cout<<mid<<std::endl;
	if(v[mid]==desired){
		return true;
	}else if(v[mid]<desired){
		return busquedaBinaria(v,start, mid-1, desired);
	}else if(v[mid]>desired){
		return busquedaBinaria(v,mid+1, end, desired);
	}else{
		return false;
	};
}
