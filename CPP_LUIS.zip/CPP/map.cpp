#include <iostream>
#include <map>

int main(int argc, char **argv){
	std::map<std::string, int> Amigos;
	Amigos["Angelo"] = 22;
	Amigos["Rafael"] = 23;
	Amigos["Jesus"] = 23;

	std::cout<<Amigos["Rafael"]<<std::endl;
	std::cout<<"Running into map"<<std::endl;

	for(auto it = Amigos.begin(); it!=Amigos.end(); it++){
		std::cout<<it->first<<" is "<<it->second<<" years old"<<std::endl;
	};
	std::cout<<Amigos["Luis"]<<std::endl;

	std::map<std::string, int>::iterator Key = Amigos.find("Jesus");
	if(Key!=Amigos.end()){
		std::cout<<Key->first<<"--"<<Key->second<<std::endl;
	}else{
		std::cout<<"You're a sucker motherfucker!!"<<std::endl;
	};

	auto Key2= Amigos.find("Carlos");
	if( Key2 != Amigos.end()){
		std::cout<<Key2->first<<"--"<<Key2->second<<std::endl;
	}else{
		std::cout<<"Suck it!"<<std::endl;
	}

	return EXIT_SUCCESS;
}
