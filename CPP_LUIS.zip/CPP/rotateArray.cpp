#include <iostream>
#include <vector>
#include "m_tools.h"

int  main(int argc, char **argv){
	/*Obtener la lista */
	//std::vector<char> v = {'G','e','e','k','f','o','r','G','e','e','k','s'};
	std::string str="GeeksforGeeks";
	int steps = 2;
	//rotateVector(v,steps,"right");
	rotateString(str,steps, "right");
	for(auto x:str){
		std::cout<<x;
	}
	std::cout<<"\n"<<std::endl;

	return EXIT_SUCCESS;
}
