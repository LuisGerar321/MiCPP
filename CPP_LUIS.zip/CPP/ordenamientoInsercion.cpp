#include <iostream>
#include <vector>
#include <time.h>


std::vector<int> ordenamientoInsercion(std::vector<int> v);


int tam=0;

std::vector<int> v;
int main(int argc, char **argv){
	srand(time(NULL));
	std::cout<<"Enter tam of list"<<std::endl;
	std::cin>>tam;
	std::cout<<"Vector desordenado: "<<std::endl;
	for(int  i=0; i<tam; i++){
		v.push_back(rand()%101);
		std::cout<<v[i]<<" ";
	}
	std::vector<int> vOrdenado = ordenamientoInsercion(v);
	std::cout<<"\nVector Ordenado: "<<std::endl;
	for(auto v : vOrdenado){
		std::cout<<v<<" ";
	}
	return EXIT_SUCCESS;
}
std::vector<int> ordenamientoInsercion(std::vector<int> v){
	int valor_actual = 0;
	int indice_actual = 0;
	for(int i=1; i<v.size(); i++){ /*Emepezar en 1 para comparar con el de la izquierda*/
		valor_actual = v[i];
		indice_actual = i-1; /*El valor de la izquierda*/
		while(indice_actual>=0){
			if(valor_actual<v[indice_actual]){
				v[indice_actual+1] = v[indice_actual];
				v[indice_actual] = valor_actual;
				indice_actual--;
			}else{
				break;
			};
		};
	};
	return v;
}
