#include <iostream>
#include <algorithm>
#include <vector>
class CasillasDeVotacion{
	private:
		int code;
		std::vector<std::string> paises;
		std::string pais;
	public:
		CasillasDeVotacion(int code_, std::vector<std::string> paises_, std::string pais_ = "None"){
			code = code_;
			paises = paises_;
			pais = pais_;
		}
	public:
		int get_code(){
			return code;
		}
		void set_code(int code_){
			code = code_;
		}
		std::string get_pais(){
			return pais;
		}
		void set_pais(std::string pais_){
			try{
				if(std::find(paises.begin(), paises.end(),pais_)!=paises.end()){
					pais= pais_;
				}else{
					throw "You're a dump!";
				}
			}
			catch(const char* x){
				std::cout<<"Error because: "<<x<<std::endl;
			};
		}
};

CasillasDeVotacion myCasilla(123, {"MEX", "USA"});

int main(int argc, char **argv){
	std::cout<<myCasilla.get_code()<<std::endl<<myCasilla.get_pais()<<std::endl;
	myCasilla.set_pais("CAN");
	myCasilla.set_pais("MEX");
	std::cout<<myCasilla.get_pais()<<std::endl;

	return EXIT_SUCCESS;
}
