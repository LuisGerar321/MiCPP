#include <iostream>
#include <vector>
#include "m_tools.h"

int main(int argc, char **argv){
	std::vector<int> v = {1,5,6,10,1,70,5,10};
	/*See the vector*/
	for(auto x:v){
		std::cout<<x<<std::endl;
	};
	v = sortVector(v);

	for(auto a:v){
		std::cout<<a<<std::endl;
	}

	return EXIT_SUCCESS;
}
