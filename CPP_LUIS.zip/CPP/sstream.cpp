#include <iostream>
#include <sstream>
#include <vector>
#include <map>


void frec_word(std::string str){
	std::stringstream ss(str);
	std::string rts;
	std::map<std::string, int> container;

	while(ss>>rts){
		container[rts]++;
	};
	for(std::map<std::string, int>::iterator it = container.begin(); it!=container.end(); it++){
		std::cout<<"\n"<<it->first<<": "<<it->second<<std::endl;
	};
}


int main(int argc, char** argv){
	std::cout<<"Frequency word in a str using sstream  template";
	frec_word("Geeks for Geeks Quizz Geeks");
	return EXIT_SUCCESS;
}
