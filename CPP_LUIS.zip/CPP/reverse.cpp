#include <iostream>
#include <iterator>

//std::vector<std::string> str= "The sky is blue";

std::string str = "The sky is blue";

int main(int argc, char** argv){
	//std::vector<std::string> str = "The sky is blue"
	std::cout<<str<<std::endl;

	for(auto it =  str.rbegin(); it!=str.rend(); it++){
		std::cout<<*it;
	}

	return EXIT_SUCCESS;
}
