#include <time.h>
#include <stdlib.h>

//srand(time(NULL));

struct AIRLINE{
	int flyNumber[10];
	char origCode[10][3];
	char destCode[10][3];
	char startTime[10][30];
	char arrivalTime[10][30];
};

int flyNumberFolio(){
	int folio=0;
	int random=0;
	do{
		random = rand()%(999+1);
	}while(random<99 && random>999);
	return random;
}

struct tm* timeStruct;
