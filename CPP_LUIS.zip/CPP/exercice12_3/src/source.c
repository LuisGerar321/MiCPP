#include <stdio.h>
#include <string.h>
#include <time.h>
#include "../include/utils.h"

struct AIRLINE aeroMex;
int i=0;
char m[30]= " ";

int main(int argc, char **argv){
	srand(time(NULL));
	//aereoMex.flyNumber[0] =flyNumberFolio();
	for(i=0; i<10; i++){
		printf("\nBienvenido a AeroMex user: %d", i);
		aeroMex.flyNumber[i]=flyNumberFolio();
		sprintf(m,"%d", flyNumberFolio());
		strcpy(aeroMex.origCode[i],m);
		sprintf(m,"%d", flyNumberFolio());
		strcpy(aeroMex.destCode[i],m);
		sprintf(m,"0%d:00 hours", i);
		strcpy(aeroMex.startTime[i],m);
		sprintf(m,"1%d:30 hours", i);
		strcpy(aeroMex.arrivalTime[i],m);
		/*Print info*/
		printf("\n\tFly number: %d\n\toring code: %s\n\tdest code %s\n\tstart time: %s\n\t arrival time: %s\n", aeroMex.flyNumber[i],aeroMex.origCode[i], aeroMex.destCode[i], aeroMex.startTime[i], aeroMex.arrivalTime[i]);

	}
	return 0;
}
